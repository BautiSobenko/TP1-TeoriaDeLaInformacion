# Teoria De La Informacion - Facultad
## Integrantes:
 * Matarazzo, Tomas
 * Rojas, Agustin
 * Priano Sobenko, Bautista
